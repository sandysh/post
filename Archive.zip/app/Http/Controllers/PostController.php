<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Post;

class PostController extends Controller
{
    public function index()
    {
        $posts = Post::latest()->orderBy('created_at')->get();
        
        return view('post.index',compact('posts'));
    }
    
    public function create(Request $request)
    {
        return view('post.create');
    }
    
    public function store(Request $request)
    {
        //dd($request->body);
        $this->validate($request,[
            'title' => 'required',
            'body'  => 'required',
            ]);
        
        $post = Post::create($request->only(['title', 'body']));
        
        return redirect('/post/create');
    }
    
    public function show(Post $post)
    {
        return view('post.show',compact('post'));
    
    }
    
    
}
