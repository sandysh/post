<?php

namespace App;
// use App\Model as Model;

class Post extends Model
{
    protected $fillable = ['title','body'];
    
    public function comments()
    {
        return $this->hasMany(Comments::class);
    }
    
    public function addComment($body)
    {
            // $this->comments()->create(['body'=> $body]);        
            $this->comments()->create(compact('body'));        
            // Comments::create([
            // 'body' => request('body'),
            // 'post_id' => $this->id,
            // ]);
    }
}
