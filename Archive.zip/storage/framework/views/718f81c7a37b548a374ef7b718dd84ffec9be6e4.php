<?php $__env->startSection('content'); ?>
<div class="col-sm-8 blog-main">
    <div class="blog-post">
                <h2 class="blog-post-title">
                    <a href="blog/<?php echo e($blog->id); ?>"><?php echo e($blog->title); ?></a>
                </h2>
                <p class="blog-post-meta"><?php echo e($blog->created_at->toFormattedDateString()); ?> by <a href="#">Mark</a></p>
                <p><?php echo e($blog->body); ?></p>
              </div><!-- /.blog-post -->
              
              <ul class="list-group">
                <?php $__currentLoopData = $blog->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="list-group-item"><?php echo e($comment->created_at->diffForHumans()); ?>: <?php echo e($comment->body); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
              
              <br><br><br><br><br>
              <?php echo $__env->make('shared.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                  <form method="POST" action="/blog/<?php echo e($blog->id); ?>/comment">
                  <?php echo e(csrf_field()); ?>

          
                    <div class="form-group">
                      <label for="body">Post a comment</label>
                      <textarea name="body" id="body" rows="5" class="form-control">
                          
                      </textarea>
                    </div>
                    <button type="submit" class="btn btn-default">Submit</button>
                  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog.blog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>